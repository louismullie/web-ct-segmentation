## Projects Using Shepherd

Here we showcase some of the awesome libraries built using Shepherd.

### [ember-shepherd](https://github.com/shipshapecode/ember-shepherd)

Ember addon for the site tour library Shepherd

### Your Project Here

If you have a cool open-source library built on Shepherd, PR this doc.
