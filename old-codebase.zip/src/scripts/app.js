$(function(){

  // Disable native browser drag and drop
  $(window).on('dragover drop', e => e.preventDefault());

})
